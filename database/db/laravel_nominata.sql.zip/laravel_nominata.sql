-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 11-06-2019 a las 05:07:53
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `laravel_nominata`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `assignments`
--

CREATE TABLE `assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `classroom_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associations`
--

CREATE TABLE `associations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `initials` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `union_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `associations`
--

INSERT INTO `associations` (`id`, `initials`, `slug`, `name`, `union_id`, `created_at`, `updated_at`) VALUES
(1, 'ASR', 'asr', 'Associação Sul Rio-Grandense', 7, '2019-06-06 03:30:05', '2019-06-06 03:35:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `careers`
--

CREATE TABLE `careers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `university_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `enabled`, `created_at`, `updated_at`) VALUES
(1, 'Programação', 'programacao', 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `classrooms`
--

CREATE TABLE `classrooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `module_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `classrooms`
--

INSERT INTO `classrooms` (`id`, `name`, `description`, `video`, `views`, `status`, `module_id`, `created_at`, `updated_at`) VALUES
(1, 'Vídeo Aula 1', 'Uma descrição qualquer', NULL, NULL, NULL, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `total_hours` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `free` tinyint(1) NOT NULL DEFAULT '0',
  `price` double(10,2) DEFAULT NULL,
  `price_plots` double(10,2) DEFAULT NULL,
  `total_plots` int(11) DEFAULT NULL,
  `link_buy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `courses`
--

INSERT INTO `courses` (`id`, `name`, `url`, `description`, `image`, `code`, `total_hours`, `published`, `free`, `price`, `price_plots`, `total_plots`, `link_buy`, `status`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'JavaFX para iniciantes', 'javafx-para-iniciantes', 'Uma descrição qualquer 1', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(2, 'VueJS para iniciantes', 'vuejs-para-iniciantes', 'Uma descrição qualquer 2', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu` int(10) UNSIGNED NOT NULL,
  `depth` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_08_11_073824_create_menus_wp_table', 1),
(4, '2017_08_11_074006_create_menu_items_wp_table', 1),
(5, '2019_02_07_201823_create_sections_table', 1),
(6, '2019_02_07_201942_create_pages_table', 1),
(7, '2019_02_07_202016_create_categories_table', 1),
(8, '2019_02_07_202439_create_posts_table', 1),
(9, '2019_02_07_202551_create_universities_table', 1),
(10, '2019_02_07_202728_create_careers_table', 1),
(11, '2019_02_07_203244_create_periods_table', 1),
(12, '2019_03_22_235123_create_courses_table', 1),
(13, '2019_03_22_235437_create_modules_table', 1),
(14, '2019_03_22_235738_create_classrooms_table', 1),
(15, '2019_03_23_134213_create_sales_table', 1),
(16, '2019_04_10_204906_create_permission_tables', 1),
(17, '2019_04_19_161613_create_assignments_table', 1),
(18, '2019_05_07_014724_create_unions_table', 1),
(19, '2019_05_07_014904_create_associations_table', 1),
(20, '2019_05_07_203304_create_trainees_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(3, 'App\\User', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `modules`
--

INSERT INTO `modules` (`id`, `name`, `description`, `status`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 'cum', 'Tempore maxime ullam sunt omnis.', NULL, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(2, 'maxime', 'Vel rerum repudiandae dolore.', NULL, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(3, 'voluptas', 'Officia dicta nihil quidem voluptatem veniam natus.', NULL, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(4, 'qui', 'Velit expedita quo et cumque amet dolores velit.', NULL, 1, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `redirect` int(11) DEFAULT NULL,
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `section_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periods`
--

CREATE TABLE `periods` (
  `id` int(10) UNSIGNED NOT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'create user', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(2, 'read users', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(3, 'update user', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(4, 'delete user', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(5, 'create role', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(6, 'read role', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(7, 'update role', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(8, 'delete role', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(9, 'create permission', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(10, 'read permission', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(11, 'update permission', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(12, 'delete permission', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(2, 'moderador', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22'),
(3, 'super-admin', 'web', '2019-05-07 05:47:22', '2019-05-07 05:47:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 2),
(4, 3),
(5, 3),
(6, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `transaction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('started','approved','canceled','pending_analysis','billet_printed','refunded','dispute','completed','blocked','chargeback','delayed','expired') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `course_id`, `transaction`, `status`, `date`, `created_at`, `updated_at`) VALUES
(1, 2, 1, NULL, NULL, NULL, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(2, 2, 2, NULL, NULL, NULL, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trainees`
--

CREATE TABLE `trainees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` char(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gender` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `marital_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_men` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `image_woman` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `content_woman` text COLLATE utf8mb4_unicode_ci,
  `external_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `redirect` char(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` tinyint(1) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `user_id` int(10) UNSIGNED NOT NULL,
  `association_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `trainees`
--

INSERT INTO `trainees` (`id`, `name`, `slug`, `email`, `phone`, `age`, `gender`, `marital_status`, `image`, `description`, `image_men`, `content`, `image_woman`, `content_woman`, `external_url`, `redirect`, `status`, `order`, `enabled`, `user_id`, `association_id`, `created_at`, `updated_at`) VALUES
(1, 'Diego Rodrigues Veríssimo', 'diego-rodrigues-verissimo', 'diegoverissimo@live.com', '(75) 9 9116.1987', '32', 'M', 'CASADO', '1560219876.png', 'asas', '1559788883.jpg', '<div class=\"col-md-6\"><img class=\"img-fluid\" src=\"http://127.0.0.1:8000/uploads/source/formandos/01/diego-2-min.png\" alt=\"\" width=\"100%\" height=\"auto\" />\r\n<p><strong>CAMPO DE ORIGEM:</strong> Uni&atilde;o Nordeste Brasileira &ndash; UNeB</p>\r\n<p><strong>ASSOCIA&Ccedil;&Atilde;O:</strong> Pernambucana Central &ndash; APeC</p>\r\n<p><strong>NATURALIDADE:</strong> Caruaru-PE</p>\r\n<p><strong>Data de Nascimento e Idade:</strong> 19/06/1987 / 31 anos</p>\r\n<p><strong>Ano de Batismo e Tempo:</strong> 30/09/1995 / 23 anos</p>\r\n<p><strong>Local de Batismo:</strong> Igreja do Vassoural - Caruaru-PE</p>\r\n<p><strong>Estado Civil:</strong> Casado</p>\r\n<p><strong>Filhos:</strong> Uma</p>\r\n<p><strong>Contato:</strong> (75) 9 9116.1987</p>\r\n<p><strong>e-mail:</strong> diegoverissimo@live.com</p>\r\n<p><strong>MINIST&Eacute;RIOS COM OS QUAIS SE IDENTIFICA:</strong></p>\r\n</div>\r\n<div class=\"col-md-6\">\r\n<ul>\r\n<li>Evangelismo</li>\r\n<li>Pessoal</li>\r\n<li>Pequenos Grupos</li>\r\n<li>Escola Sabatina</li>\r\n<li>Comunica&ccedil;&atilde;o</li>\r\n<li>Jovem</li>\r\n<li>Desbravadores</li>\r\n<li>Aventureiros</li>\r\n<li>Fam&iacute;lia</li>\r\n<li>Capelania</li>\r\n<li>M&uacute;sica</li>\r\n</ul>\r\n<p><strong>FORMA&Ccedil;&Otilde;ES E OUTRAS COMPET&Ecirc;NCIAS:</strong></p>\r\n<ul>\r\n<li><strong>Graduando em Teologia -</strong>Semin&aacute;rio Adventista Latino-americano de Teologia SALT / FADBA - 2019</li>\r\n<li><strong>Bacharel em Design Gr&aacute;fico -</strong> Universidade Federal de Pernambuco &ndash; UFPE - 2017)</li>\r\n<li><strong>T&eacute;cnico em Web Designer -</strong>Microcamp (2008)</li>\r\n</ul>\r\n<p><strong>EXPERI&Ecirc;NCIAS PROFISSIONAIS:</strong></p>\r\n<ul>\r\n<li><strong>Marketing da FADBA -</strong> Designer Publicit&aacute;rio - 2016-2018</li>\r\n<li>Alguns Projetos gr&aacute;ficos realizados:</li>\r\n<li><strong>Associa&ccedil;&atilde;o Geral</strong> Departamento de Publica&ccedil;&otilde;es - 2019</li>\r\n<li><strong>Divis&atilde;o Sul-Americana: </strong>Departamento de Publica&ccedil;&otilde;es - 2019</li>\r\n<li><strong>IDEC:</strong> FADBA / UNASP Campus I e II &ldquo;At&eacute; que Ele venha&rdquo; - 2019</li>\r\n<li><strong>UNeB:</strong> Assinatura visual e artes Colportagem Nordeste - 2018-2019</li>\r\n<li><strong>FADBA / P&oacute;s-gradua&ccedil;&atilde;o - </strong>2017-2018</li>\r\n<li><strong>SALT - </strong>Assinatura visual (premiada) da Editora - 2017</li>\r\n<li><strong>Designer Gr&aacute;fico - </strong>2011-2015:</li>\r\n<li>Gr&aacute;fica e Editora Offset</li>\r\n<li>Serigrafia</li>\r\n<li>Flexografia</li>\r\n</ul>\r\n<p><strong><u>ATIVIDADES DESENVOLVIDAS NO SALT-FADBA:</u></strong></p>\r\n<ul>\r\n<li><strong>Diretor de Arte -</strong> Site da Nominata - 2019</li>\r\n<li><strong>Miss&atilde;o Iaenense - </strong>Departamental de M&uacute;sica - 2019</li>\r\n<li><strong>Diretor musical -</strong> L&oacute;gos (Quarteto do SALT) - 2019</li>\r\n<li><strong>Comiss&atilde;o de formatura - </strong>Designer Gr&aacute;fico da turma 61 - 2019</li>\r\n<li><strong>Coordenador de Pr&aacute;tica e Pequenos Grupos - </strong>Cria&ccedil;&atilde;o da Rede de PG&rsquo;s e Prot&oacute;tipo PG (<em>Alfa</em>) da IASD Jardim Petrolar, Alagoinhas-BA - 2019</li>\r\n<li><strong>Diret&oacute;rio Acad&ecirc;mico - </strong>Diretor de Marketing - 2018</li>\r\n<li><strong>Clube de Aventureiros - </strong>Instrutor - 2018</li>\r\n<li><strong>Pr&aacute;tica Pastoral - </strong>Cria&ccedil;&atilde;o do Pequeno Grupo prot&oacute;tipo (<em>Beta</em>) da IASD Jardim Petrolar, Alagoinhas-BA - 2017-2018</li>\r\n<li><strong>Desbravadores - </strong>L&iacute;der - 2017</li>\r\n<li><strong>L&oacute;gos Quarteto - </strong>Membro - 2016-2019</li>\r\n<li><strong>Pequenos Grupo Prot&oacute;tipo de Teologandos &ndash; </strong>L&iacute;der - 2016</li>\r\n<li><strong>Comunica&ccedil;&atilde;o da Igreja do Campus &ndash; </strong>Auxiliar - 2016</li>\r\n</ul>\r\n<p><strong><u>EVANGELISMO P&Uacute;BLICO E PLANTIO DE IGREJAS:</u></strong></p>\r\n<ul>\r\n<li><strong>Evangelismo P&uacute;blico - </strong>2</li>\r\n<li><strong>Semana do Calv&aacute;rio - </strong>2010-2019</li>\r\n<li><strong>Obreiro Evangelista - </strong>2010</li>\r\n<li><strong>Miss&atilde;o Calebe - </strong>2006-2010</li>\r\n</ul>\r\n<p><strong><u>EXPERI&Ecirc;NCIA COMO COLPORTOR EVANGELISTA:</u></strong></p>\r\n<ul>\r\n<li><strong>IDEC - </strong>Palestrante para Colportores Veteranos de igrejas evang&eacute;licas - 2018</li>\r\n<li><strong>Escola de L&iacute;deres do IDEC - </strong>Palestrante sobre Marketing &ndash; 2018</li>\r\n<li><strong>Escola de L&iacute;deres do IDEC - </strong>Formado &ndash;2017</li>\r\n<li><strong>Colportagem - </strong>L&iacute;der - 2017.2</li>\r\n<li><strong>UNeB Minist&eacute;rio Publica&ccedil;&otilde;es - </strong>Colportor Destaque por 2 anos no segmento de Igreja Evang&eacute;lica - 2016/2017</li>\r\n</ul>\r\n<p><strong><u>ATIVIDADES DESENVOLVIDAS NA IGREJA DE ORIGEM:</u></strong></p>\r\n<ul>\r\n<li><strong>Anci&atilde;o Ordenado - </strong>4 anos</li>\r\n<li><strong>Tesoureiro - </strong>4 anos</li>\r\n<li><strong>Minist&eacute;rio Jovem - </strong>Diretor - 3 anos</li>\r\n<li><strong>Clube de Jovens - </strong>L&iacute;der investido no Campor&iacute; da UNeB, Jovens Por Uma Paix&atilde;o - 2007</li>\r\n<li><strong>Pequeno Grupo Jovem - </strong>L&iacute;der - 2 anos</li>\r\n<li><strong>Minist&eacute;rio da M&uacute;sica - </strong>Diretor - 5 anos</li>\r\n<li><strong>Clube de Desbravadores - </strong>Conselheiro - 2 anos</li>\r\n<li><strong>Clube de Desbravadores - </strong>Capel&atilde;o - 1 ano</li>\r\n</ul>\r\n</div>', '1559788883.jpg', '<h2><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://127.0.0.1:8000/uploads/source/formandos/01/diego-3-min.png\" alt=\"\" width=\"487\" height=\"487\" />EDITTE SOARES DE ABREU VER&Iacute;SSIMO</strong></h2>\r\n<p><strong>CAMPO DE ORIGEM:</strong> Uni&atilde;o Nordeste Brasileira &ndash; UNeB</p>\r\n<p><strong>ASSOCIA&Ccedil;&Atilde;O:</strong> Pernambucana Central &ndash; APeC</p>\r\n<p><strong>NATURALIDADE:</strong> Goi&acirc;nia-GO</p>\r\n<p><strong>Data de Nascimento e Idade:</strong> 06/12/1987 / 31 anos</p>\r\n<p><strong>Ano de Batismo e Tempo</strong>: 30/09/01 / 17 anos</p>\r\n<p><strong>Local de Batismo:</strong> Lagoa dos Gatos-PE</p>\r\n<p><strong>N&uacute;mero de Telefone:</strong> (71) 9 9976.9225</p>\r\n<p><strong>e-mail:</strong> edittesoares@hotmail.com</p>\r\n<p><strong>MINIST&Eacute;RIOS COM OS QUAIS SE IDENTIFICA:</strong></p>\r\n<ul>\r\n<li>ASA</li>\r\n<li>ADRA</li>\r\n<li>Sa&uacute;de</li>\r\n<li>Pessoal</li>\r\n<li>Fam&iacute;lia</li>\r\n<li>Jovens</li>\r\n<li>Mulher</li>\r\n<li>Crian&ccedil;a</li>\r\n</ul>\r\n<p><strong>FORMA&Ccedil;&Otilde;ES E OUTRAS COMPET&Ecirc;NCIAS:</strong></p>\r\n<ul>\r\n<li><strong>Especialista em Fisioterapia Dermatofuncional - </strong>Faculdade Inspirar, Curitiba-PR - 2014</li>\r\n<li><strong>Bacharelado em Fisioterapia -</strong> ASCES UNITA, Caruaru-PE - 2012</li>\r\n</ul>\r\n<p><strong>EXPERI&Ecirc;NCIAS PROFISSIONAIS: </strong></p>\r\n<ul>\r\n<li><strong>Atua&ccedil;&atilde;o Cl&iacute;nica em Fisioterapia - </strong>2012-2019</li>\r\n</ul>\r\n<p><strong>ATIVIDADES DESENVOLVIDAS ENQUANTO ESPOSA DE TEOLOGANDO:</strong></p>\r\n<ul>\r\n<li><strong>Aprendendo a ser mam&atilde;e AFAM - </strong>Diretora do Curso &ndash; 2019</li>\r\n<li><strong>Minist&eacute;rio da Mulher AFAM</strong> <strong>-</strong> 2019</li>\r\n<li><strong>Minist&eacute;rio de Comunica&ccedil;&atilde;o AFAM</strong> <strong>-</strong> 2019</li>\r\n<li><strong>AFAM</strong> <strong>-</strong> Participa&ccedil;&atilde;o em todos os anos</li>\r\n<li><strong>Classe Rol do Ber&ccedil;o</strong> <strong>-</strong> Professora auxiliar &ndash; 2 anos</li>\r\n<li><strong>Feiras de Sa&uacute;de - </strong>Participa&ccedil;&atilde;o</li>\r\n<li><strong>Palestrante</strong> <strong>-</strong> Tem&aacute;tica feminina</li>\r\n</ul>\r\n<p><strong>ATIVIDADES NA IGREJA DE ORIGEM:</strong></p>\r\n<ul>\r\n<li><strong>Secret&aacute;ria -</strong> 2 anos</li>\r\n<li><strong>Secret&aacute;ria da Escola Sabatina</strong> <strong>-</strong> 1 ano</li>\r\n<li><strong>Tesoureira -</strong> 2 anos</li>\r\n<li><strong>Coordenadora de Interessados -</strong> 2 anos</li>\r\n<li><strong>Diretora de Comunica&ccedil;&atilde;o -</strong> 2 anos</li>\r\n<li><strong>Diretora de Recep&ccedil;&atilde;o -</strong> 2 anos</li>\r\n<li><strong>L&iacute;der de Pequenos Grupos -</strong> 1 ano</li>\r\n<li><strong>Professora da Classe de Jovens -</strong> 2 anos</li>\r\n<li><strong>L&iacute;der de Jovens - </strong>investida no Campor&iacute; da UNeB, Jovens Por Uma Paix&atilde;o - 2007</li>\r\n<li><strong>Clube de Desbravadores -</strong> Diretora Associada - 1 ano</li>\r\n<li><strong>Clube de Desbravadores &ndash; </strong>Conselheira - 1 ano</li>\r\n<li><strong>Clube de Desbravadores -</strong> Capel&atilde; - 1 ano</li>\r\n<li><strong>Clube de Desbravadores -</strong> Tesoureira - 2 anos</li>\r\n</ul>\r\n<p><strong>EVANGELISMO P&Uacute;BLICO E PLANTIO DE IGREJA:</strong></p>\r\n<ul>\r\n<li><strong>Miss&atilde;o Calebe - </strong>Caruaru-PE - 2008</li>\r\n<li><strong>Evangelismo - </strong>Maria de F&aacute;tima Freire - Arcoverde-PE - 2018</li>\r\n</ul>\r\n<p><strong>COLPORTAGEM:</strong></p>\r\n<ul>\r\n<li><strong>Seguimento porta a porta -</strong> Santa Cruz do Capibaribe-PE - 2016</li>\r\n</ul>', NULL, '0', 1, 1, 1, 3, 1, '2019-06-06 05:41:23', '2019-06-11 06:03:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unions`
--

CREATE TABLE `unions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `initials` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `unions`
--

INSERT INTO `unions` (`id`, `initials`, `slug`, `name`, `created_at`, `updated_at`) VALUES
(1, 'UCB', 'ucb', 'União Central Brasileira', NULL, '2019-06-06 02:48:08'),
(2, 'ULB', 'ulb', 'União Leste Brasileira', NULL, '2019-06-06 02:48:33'),
(3, 'UCoB', 'ucob', 'União Centro-Oeste Brasileira', NULL, '2019-06-06 02:49:01'),
(4, 'UNB', 'unb', 'União Norte Brasileira', NULL, '2019-06-06 02:50:02'),
(5, 'UNeB', 'uneb', 'uZAuVS54Nge02y7wlUCI', NULL, NULL),
(6, 'UNoB', 'unob', 'CHYFyWO3iN47jjAQ7dST', NULL, NULL),
(7, 'USB', 'usb', 'Ghqoe6hhxoQbDI7242cy', NULL, NULL),
(8, 'USeB', 'useb', 'Z9RKKesNsbshCd3sYM1X', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `universities`
--

CREATE TABLE `universities` (
  `id` int(10) UNSIGNED NOT NULL,
  `initials` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'editor', 'editor@gmail.com', '$2y$10$P8KwUgmshrSQpt7wbepwsONnhym2h2HzAmPnj2LlfBFStQmYIw/hC', NULL, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(2, 'moderador', 'moderador@gmail.com', '$2y$10$7F6mFBifSK92UspnhmTF1.YHNQulW7U8m7AKdfhBEsr5pqaoRSiEq', NULL, '2019-05-07 05:47:23', '2019-05-07 05:47:23'),
(3, 'admin', 'admin@gmail.com', '$2y$10$4mDxknnWP2EpM1D8DFAKu.kiIqvJZX9RnGnyAACXUYOdYb8eRiaDO', NULL, '2019-05-07 05:47:23', '2019-05-07 05:47:23');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignments_user_id_foreign` (`user_id`),
  ADD KEY `assignments_classroom_id_foreign` (`classroom_id`);

--
-- Indices de la tabla `associations`
--
ALTER TABLE `associations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `associations_initials_unique` (`initials`),
  ADD UNIQUE KEY `associations_slug_unique` (`slug`),
  ADD KEY `associations_union_id_foreign` (`union_id`);

--
-- Indices de la tabla `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `careers_university_id_foreign` (`university_id`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indices de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classrooms_module_id_foreign` (`module_id`);

--
-- Indices de la tabla `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courses_url_unique` (`url`),
  ADD UNIQUE KEY `courses_code_unique` (`code`),
  ADD KEY `courses_user_id_foreign` (`user_id`),
  ADD KEY `courses_category_id_foreign` (`category_id`);

--
-- Indices de la tabla `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_foreign` (`menu`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indices de la tabla `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modules_course_id_foreign` (`course_id`);

--
-- Indices de la tabla `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`),
  ADD KEY `pages_section_id_foreign` (`section_id`),
  ADD KEY `pages_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `periods`
--
ALTER TABLE `periods`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_category_id_foreign` (`category_id`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indices de la tabla `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_user_id_foreign` (`user_id`),
  ADD KEY `sales_course_id_foreign` (`course_id`);

--
-- Indices de la tabla `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sections_slug_unique` (`slug`);

--
-- Indices de la tabla `trainees`
--
ALTER TABLE `trainees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainees_user_id_foreign` (`user_id`),
  ADD KEY `trainees_association_id_foreign` (`association_id`);

--
-- Indices de la tabla `unions`
--
ALTER TABLE `unions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unions_initials_unique` (`initials`),
  ADD UNIQUE KEY `unions_slug_unique` (`slug`);

--
-- Indices de la tabla `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `associations`
--
ALTER TABLE `associations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `periods`
--
ALTER TABLE `periods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `trainees`
--
ALTER TABLE `trainees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `unions`
--
ALTER TABLE `unions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`),
  ADD CONSTRAINT `assignments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `associations`
--
ALTER TABLE `associations`
  ADD CONSTRAINT `associations_union_id_foreign` FOREIGN KEY (`union_id`) REFERENCES `unions` (`id`);

--
-- Filtros para la tabla `careers`
--
ALTER TABLE `careers`
  ADD CONSTRAINT `careers_university_id_foreign` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`);

--
-- Filtros para la tabla `classrooms`
--
ALTER TABLE `classrooms`
  ADD CONSTRAINT `classrooms_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `courses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_foreign` FOREIGN KEY (`menu`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Filtros para la tabla `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  ADD CONSTRAINT `pages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `trainees`
--
ALTER TABLE `trainees`
  ADD CONSTRAINT `trainees_association_id_foreign` FOREIGN KEY (`association_id`) REFERENCES `associations` (`id`),
  ADD CONSTRAINT `trainees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
